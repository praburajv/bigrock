The solution SolutionEscher.slnis a visual studio 2019 solution file and It  has 3 project.  

#.[Following are the name of the project and its output type].
1. 	EscherConsole		  (Console Application)
2.	EscherLib			  (Class Library)	
3.	EscherLib.UnitTests   (Class Library)


#[Platform Details]

1.[FrameWork]
.Net FrameWork 4.4.2

2.[Visual Studio]
Visual Studio 2019

3.[C# Version]
C#  7.3


#[SolutionEscher General Information]  

1.#[EscherConsole]
The console appliction "EscherConsole"  consumes   EscherLib.  
The following two keys are defined in the app.config file   "PersonDetailsFileNameAndPath" , "SpousesFileNameAndPath" . Directory paths can be given as per wish. 
But the given  folder  should  exist, application  will not create the folders.


2.#[EscherLib]

This lib application has all the business logic for this solution. Its public member  can be accessed across different .net platforms. 


3.#[EscherLib.UnitTests]

This unittest application has all the  asserts with multiple  test cases.



