﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
namespace EscherLib
{
    public class PersonDetails
    {
        // private Nullable<bool> temp { get; set; }
        //public bool  IsParentsAllowRegistration_1 { get; set; }
        public event EventHandler<string> PubMessages;

        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string SpouseName { get; set; }
        public string SpousefilePath { get; set; }
        public string PersonDetailsfilePath { get; set; }
        public string ParentsAllowRegistration { get; set; }
        public bool  IsMarried { get; set; }



        public DateTime  DateOfBirth { get; set; }

        private readonly IFileCreation _fileCreation = null;
        /// <summary>
        /// Constructor method takes in IFileCreation type  as an input parameter.
        /// </summary>
        /// <param name="FileCreation"></param>
        public PersonDetails(IFileCreation FileCreation =null) {
            _fileCreation =FileCreation ?? new FileCreation();
        }

        public bool CheckFortheExistenceOftheGivenFolderPath(string folderOrFilePath)
        {
            //
            bool retVal = true;
            int arrayLength = 0;
            string folderPathToCheck = string.Empty;

            if ( string.IsNullOrEmpty( folderOrFilePath))
            {
                retVal = false;
                throw new NullReferenceException();

            }

                if (!folderOrFilePath.Contains(@":\"))
            {
                retVal = false;
                throw new FormatException();
            }


            arrayLength = folderOrFilePath.Split('\\').Length;
            var splitFolderNames = from n in folderOrFilePath.Split('\\')
                                   where ((n.Contains(".txt") == false) && (n.Contains(".log") == false))
                                   select n;


            folderPathToCheck = String.Join(@"\", splitFolderNames);

            if (!Directory.Exists(folderPathToCheck))
            {
                retVal = false;
                throw new DirectoryNotFoundException();
            }
            
            
            return (retVal);

        }
        /// <summary>
        /// This method will take in PersonDetails data type as a parameter. It will do a validation for empty and null values for the 
        /// following fields in the input object SpouseName,SpousefilePath , if exist it will raise an NullReferenceException
        /// And also checks for the valid dictories paths and confirms its existence. Finally it will call a method in the fileCreation class
        /// to create a record of this in a file.
        /// </summary>
        /// <param name="personDetails"></param>
        /// <returns></returns>
        public bool CreatePersonDetailsRecord(PersonDetails personDetails)
        {
            bool funcRetVal = false;
            bool folderPathValidation = true;
            
                if (personDetails.IsMarried)
                {
                    if (string.IsNullOrEmpty(personDetails.SpouseName) || string.IsNullOrEmpty( personDetails.SpousefilePath))
                    {
                        funcRetVal = false;
                        throw new NullReferenceException();
                    }

                folderPathValidation = CheckFortheExistenceOftheGivenFolderPath(personDetails.SpousefilePath);
                folderPathValidation = CheckFortheExistenceOftheGivenFolderPath(personDetails.PersonDetailsfilePath);


              //  if (CheckFortheExistenceOftheGivenFolderPath(personDetails.SpousefilePath)) { }
                
            }
            if (folderPathValidation)
            {

                funcRetVal= _fileCreation.CreatePersonDetails(personDetails: personDetails);
            } else
            {
                funcRetVal = false;
            }
            return (funcRetVal);
        }
        /// <summary>
        /// This method will take a date type as a input and it will cross check with the current datetime if the number of 
        /// years between 16 and 18 then it will return a boolean type with a value true other wise it will be false.
        /// </summary>
        /// <param name="dateOfBirth"></param>
        /// <returns></returns>
        public bool CheckAgeIsBetween16And18(DateTime dateOfBirth)
        {
            bool retVal = false;
            int age = ((DateTime.Now - dateOfBirth).Days / 365);
            this.DateOfBirth = dateOfBirth;

            if (age >= 16 && age <18)
            {
                retVal = true;
            }

            return (retVal);
        }
        /// <summary>
        /// This method will take a date type as a input and it will cross check with the current datetime if the number of 
        /// years under 16 then it will return a boolean type with a value true other wise it will be false.
        /// </summary>
        /// <param name="DateOfBirth"></param>
        /// <returns></returns>
        public bool CheckAgeIsUnder16(DateTime DateOfBirth)
        {
            bool retVal = false;
            int age = ((DateTime.Now - DateOfBirth).Days / 365);

            if (age < 16)
            {
                PubMessages(this, "Access is denied for under 16");

                //PubMessages?.Invoke(this, "");

                retVal = true;
            } 

            return (retVal);
        }

    }


   


}
