﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;

namespace EscherLib
{
    /// <summary>
    /// This class is use to create file.
    /// </summary>
   public interface IFileCreation
    {
        bool CreateSpouseDetails(string spouseName, string fileNameAndPath);
        bool CreatePersonDetails(PersonDetails personDetails);
    }
    public class FileCreation: IFileCreation
    {
        public FileCreation() { }
        /// <summary>
        /// This class takes two string parameters. Writes the spouse name in give path "fileNameAndPath" . 
        /// </summary>
        /// <param name="spouseName"></param>
        /// <param name="fileNameAndPath"></param>
        /// <returns></returns>
        public bool CreateSpouseDetails(string spouseName,string fileNameAndPath) {

            bool retVal = true;

            try
            {
                //FileStream fs = new FileStream(fileNameAndPath,FileMode.Create);
                using (StreamWriter fileWriter = new StreamWriter(fileNameAndPath))
                {
                    fileWriter.WriteLine(string.Format("spouseName = {0} ", spouseName));
                    fileWriter.Close();
                }
            } catch (Exception Ex) {
                //throw new Exception("");
                //throw new ArgumentOutOfRangeException();
                retVal = false;
            }
            return (retVal);
        }
        /// <summary>
        /// This method takes one argument which is a PersonDetails data type.  It will construct a text details 
        /// information from the  object properties and writes to a file.
        /// </summary>
        /// <param name="personDetails"></param>
        /// <returns></returns>
        public bool CreatePersonDetails(PersonDetails personDetails)
        {
            bool retVal = true;

            string WritePersonDetails = string.Empty;
            
            #region DataReferenceExample
            //John | Doe | 01 - 12 - 1980 | Single | null | c:\people\spouses\Anna.txt
            //Paul | Murphy | 01 - 12 - 2001 | Single | yes |
            #endregion

            try
            {
                WritePersonDetails = string.Format(
                    "{0} | {1} | {2} | {3} | {4} | {5}",
                    personDetails.FirstName,
                    personDetails.SurName,
                    personDetails.DateOfBirth.ToString("dd-MM-yyyy"),
                    personDetails.IsMarried ? "Married" : "Single",
                    personDetails.ParentsAllowRegistration = string.IsNullOrEmpty(personDetails.ParentsAllowRegistration) ? "null" : personDetails.ParentsAllowRegistration,
                    personDetails.SpousefilePath);
                    

                using (StreamWriter fileWriter = new StreamWriter(personDetails.PersonDetailsfilePath,true))
                {
                    fileWriter.WriteLine(WritePersonDetails);
                    fileWriter.Close();
                }

                if (personDetails.IsMarried)
                {
                    retVal=CreateSpouseDetails(personDetails.SpouseName, personDetails.SpousefilePath);
                }

            } catch (Exception Ex) {
                retVal = false;
            }
            return (retVal);
        }


    }
}
