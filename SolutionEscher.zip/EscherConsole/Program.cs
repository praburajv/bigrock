﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using EscherLib;
using System.IO;
using System.Threading;
namespace EscherConsole
{
    class Program
    {

        static StringBuilder enteredDataDetailsBytheUser = new StringBuilder();
        static void Main(string[] args)
        {
            

            #region CODE

            string FirstName = string.Empty;
            string SurName = string.Empty;
            string IsMarried = string.Empty;
            string SpouseName = string.Empty;
            string DateOfBirth = string.Empty;
            string IsParentsAllowRegistration = string.Empty;
            string validationErrorMessage = string.Empty;

            bool PersonDetailsFormValidation = true;

            PersonDetails personDetails = new PersonDetails();
            personDetails.PubMessages += PersonDetails_PubMessages1;

            #region Screen Inputs
            try
            {
                while (string.IsNullOrEmpty( FirstName))
                {
                    Console.WriteLine("Enter FirstName * ");

                    FirstName = Console.ReadLine().TrimEnd();
                    Console.Clear();
                }

                BuildEnteredDataDetails(string.Format("FirstName :{0}", FirstName));
                //Console.Clear();
                




                while (string.IsNullOrEmpty(SurName))
                {
                    Console.WriteLine( getUserEntredData());

                    Console.WriteLine("Enter SurName * ");
                    SurName = Console.ReadLine().TrimEnd();
                    Console.Clear();
                }

                //Console.Clear();
                BuildEnteredDataDetails(string.Format("SurName :{0}", SurName));


                while (string.IsNullOrEmpty(IsMarried))
                {
                    Console.WriteLine(getUserEntredData());
                    Console.WriteLine("Enter Married (Y/N) * ");
                    IsMarried = Console.ReadLine().TrimEnd();

                    if (!(IsMarried=="Y" || IsMarried == "N"))
                    {
                        IsMarried = string.Empty;
                    }
                    Console.Clear();
                }
                
                BuildEnteredDataDetails(string.Format("IsMarried :{0}", IsMarried));


                SpouseName = string.Empty;
                if (IsMarried.ToUpper() == "Y")
                {
                    Console.WriteLine(getUserEntredData());

                    while (string.IsNullOrEmpty(SpouseName))
                    {
                        Console.WriteLine("Enter your Spouse Name * ");
                        SpouseName = Console.ReadLine().TrimEnd();
                        Console.Clear();
                    }

                    
                    BuildEnteredDataDetails(string.Format("SpouseName :{0}", SpouseName));
                }


                //Console.WriteLine(getUserEntredData());

                while (string.IsNullOrEmpty(DateOfBirth))
                {
                    Console.WriteLine(getUserEntredData());

                    Console.WriteLine("Enter DateOfBirth (DD-MM-YYYY) * ");
                    DateOfBirth = Console.ReadLine().TrimEnd();

                    try
                    {
                        DateTime.Parse(DateOfBirth);
                    }
                    catch (Exception Ex)
                    {
                        Console.WriteLine( string.Format("Error : {0}", Ex.Message));
                        DateOfBirth = string.Empty;
                        Thread.Sleep(2000);
                        Console.Clear();
                    }
                    Console.Clear();
                }

                //Console.Clear();
                BuildEnteredDataDetails(string.Format("DateOfBirth :{0}", DateOfBirth));

                Console.WriteLine(getUserEntredData());

                if (personDetails.CheckAgeIsUnder16(DateOfBirth: DateTime.Parse(DateOfBirth)))
                {
                    PersonDetailsFormValidation = false;
                }
            } catch (Exception Ex) {
                validationErrorMessage = Ex.Message;
            }

            if (PersonDetailsFormValidation)
            {
                if (personDetails.CheckAgeIsBetween16And18(dateOfBirth: DateTime.Parse(DateOfBirth)))
                {

                    while (string.IsNullOrEmpty(IsParentsAllowRegistration))
                    {
                        Console.WriteLine("My parents allow registration  (Y/N)");
                        IsParentsAllowRegistration = Console.ReadLine().TrimEnd();
                        if (IsParentsAllowRegistration == "N")
                        {
                            MessageAlert("Access to the registration is deny");
                            PersonDetailsFormValidation = false;
                        }
                    }

                }

            }

            #endregion

            #region After Validation , Processing  the Inputs 
            if (PersonDetailsFormValidation)
            {
                
                personDetails.FirstName = FirstName;
                personDetails.SurName = SurName;
                personDetails.IsMarried = IsMarried.ToUpper() == "Y" ? true : false;
                personDetails.ParentsAllowRegistration = IsParentsAllowRegistration.ToUpper() == "Y" ? "YES" : null;
                personDetails.SpouseName = SpouseName;
                personDetails.PersonDetailsfilePath = ConfigurationManager.AppSettings["PersonDetailsFileNameAndPath"].ToString();

                if (personDetails.IsMarried)
                    personDetails.SpousefilePath = string.Format(ConfigurationManager.AppSettings["SpousesFileNameAndPath"].ToString(),string.Format("{0}-{1}", SpouseName, Guid.NewGuid().ToString()));

                try
                {
                    if (personDetails.CreatePersonDetailsRecord(personDetails))
                    {
                        Console.WriteLine("Record Successfully Created");
                        Thread.Sleep(2000);

                    }
                } catch (Exception Ex) {

                    MessageAlert( string.Format("Exception {0}", Ex.Message));

                }
            } else
            {
                MessageAlert( string.Format(" Validation Error=[{0}], access to the  registration is denied ", validationErrorMessage) );

            }
            #endregion


            #endregion

        }


         

       private static  void BuildEnteredDataDetails(string enteredDataDetails)
        {
            Console.Clear();
            enteredDataDetailsBytheUser.Append(string.Format("{0}{1}", enteredDataDetails,Environment.NewLine));
        }

        private static string getUserEntredData()
        {
            return ( string.Format("{0}{2}{1}{2}{0}", "============================================================",enteredDataDetailsBytheUser.ToString(),Environment.NewLine ));

        }

        private static void PersonDetails_PubMessages1(object sender, string eventMessage)
        {
            MessageAlert(eventMessage);
        }


        private static void MessageAlert(string alertConsoleMessage)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(alertConsoleMessage);
            Console.Read();
            Console.ResetColor();
        }



         
    }
}
