﻿using System;
using NUnit.Framework;
using Moq;
using EscherLib;

namespace EscherLib.UnitTests
{
    [TestFixture]
    public class FileCreationUnitTest
    {
        private FileCreation _fileCreation = null;

        [SetUp]
        public void setup() {

            _fileCreation = new FileCreation();
        }

        /// <summary>
        /// This test is used to test valid and a non valid data.
        /// </summary>
        /// <param name="spouseName"></param>
        /// <param name="fileNameAndPath"></param>
        /// <param name="exceptedResult"></param>
        [Test]
        [TestCase("Anna", @"c:\people\spouses\Anna_UnitTest_102.txt", true)] // If the folder "people" don't exist a failure in the unit test can happen.
        [TestCase("Anna", @"c:\people\spouse\Anna_UnitTest_102.txt", false)] // Wrong spouse Location is given to simulate a failure.
        public void CreateSpouseDetails_CreateOneRecord_ReturnTrue(string spouseName,string fileNameAndPath, bool exceptedResult)
        {

           var result= _fileCreation.CreateSpouseDetails(spouseName, fileNameAndPath);

            Assert.That(result,Is.EqualTo(exceptedResult) );

        }
    }
}
