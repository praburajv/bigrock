﻿using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using EscherLib;
using Moq;
using System.IO;

namespace EscherLib.UnitTests
{
    [TestFixture]
    public class PersonDetailsUnitTest
    {
        private  PersonDetails _personDetails = null;
        
        [SetUp]
        public void SetUp() {
            _personDetails  =new PersonDetails();
        }

        [Test]
        public void TestMethod1()
        {
        }


        [Test]
        [TestCase("12-02-1975",false)]
        [TestCase("12-02-2002", true)]
        //AAA
        public void CheckAgeIsBetween16And18_AgeBetween16and18_ReturnTrueorFalse(string dateOfBirth,bool expectedResult) {

            var result = _personDetails.CheckAgeIsBetween16And18(DateTime.Parse(dateOfBirth));
            Assert.That(result, Is.EqualTo(expectedResult) );

        }



        [Test]
        [TestCase("12-02-1975", false)]
        //AAA
        public void CheckAgeIsUnder16_AgeUnder16_ReturnTrueorFalse(string dateOfBirth, bool expectedResult)
        {

            var result = _personDetails.CheckAgeIsUnder16(DateTime.Parse(dateOfBirth));
            Assert.That(result, Is.EqualTo(expectedResult));

        }

        [Test]
         [TestCase("12-02-2005", true)]
        //AAA
        public void CheckAgeIsUnder16_AgeUnder16_ReturnEventMessage(string dateOfBirth, bool expectedResult)
        {

            string eventMessage = string.Empty;
            _personDetails.PubMessages += (sender, args) => { eventMessage = args; };

            var result = _personDetails.CheckAgeIsUnder16(DateTime.Parse(dateOfBirth));
            Assert.That(eventMessage, Is.Not.EqualTo(string.Empty));

        }




        [Test]
        //FirstName | Surname | Marital status  | SpouseName | Date of birth | parents allow registration | SpouseFilePath | PeopleFilePath
        [TestCase("Jhon", "Thomas", "true", "", "12-02-1975", "", @"C:\people\spouses\Julia_UnitTest_203.txt", @"C\:people\People_UnitTest.txt")] // Sending  SpouseName empty , when martial status is true.
        [TestCase("Jhon", "Thomas", "true", "Julia", "12-02-1975", "", "", @"C\:people\People_UnitTest.txt")]  //  Sending SpouseFilePath Empty.
        public void CreatePersonDetailsRecord_SpouseNameEmpty_NullReferenceException
            (
            string firstName, string surName, string maritalStatus, string spouseName, string dateOfBirth, string ParentsAllowRegistration,
            string SpouseDetailsfilePath, string PersonDetailsfilePath
            )
        {
            PersonDetails personDetails = new PersonDetails()
            {
                FirstName = firstName,
                SurName = surName,
                IsMarried = bool.Parse(maritalStatus),
                SpouseName = spouseName,
                DateOfBirth = DateTime.Parse(dateOfBirth),
                ParentsAllowRegistration = ParentsAllowRegistration,

                SpousefilePath = SpouseDetailsfilePath,
                PersonDetailsfilePath = PersonDetailsfilePath
            };

            Assert.That(() => _personDetails.CreatePersonDetailsRecord(personDetails),Throws.Exception.TypeOf<NullReferenceException>());

        }


        [Test]
        [TestCase(@"c:\people",true)]
        public void CheckFortheExistenceOftheGivenFolderPath_FullExistingFolderPath_ReturnTrue(string folderPath, bool expectedResult) {

            var result=_personDetails.CheckFortheExistenceOftheGivenFolderPath(folderPath);
            Assert.That(result, Is.EqualTo(expectedResult));

        }


        [Test]
        [TestCase(@"")]
        public void CheckFortheExistenceOftheGivenFolderPath_WrongFolderPath_NullReferenceException(string folderPath)
        {

            Assert.That(() => _personDetails.CheckFortheExistenceOftheGivenFolderPath(folderPath), Throws.Exception.TypeOf<NullReferenceException>());
        }

        [Test]
        [TestCase(@"c\:people")]
        public void CheckFortheExistenceOftheGivenFolderPath_WrongFolderPath_FormatException(string folderPath)
        {

            Assert.That(() => _personDetails.CheckFortheExistenceOftheGivenFolderPath(folderPath), Throws.Exception.TypeOf<FormatException>());

        }

        [Test]
        [TestCase(@"c:\peoples")]
        public void CheckFortheExistenceOftheGivenFolderPath_WrongFolderPath_DirectoryNotFoundException(string folderPath)
        {
            Assert.That(() => _personDetails.CheckFortheExistenceOftheGivenFolderPath(folderPath), Throws.Exception.TypeOf<DirectoryNotFoundException>());

        }



        [Test]
        //FirstName | Surname | Marital status  | SpouseName | Date of birth | parents allow registration | SpouseFilePath | PeopleFilePath
        [TestCase("Jhon", "Thomas", "true", "Julia", "12-02-1975", "", @"C:\people\spouses\Julia_UnitTest_203.txt", @"C:\people\people_UnitTest.txt", true)] // Sending all the datas
        [TestCase("Robet", "James", "false", "", "12-02-1975", "", @"C:\people\spouses\Julia_UnitTest_203.txt", @"C:\people\people_UnitTest.txt", true)] // sending martial status false and spouse name empty
        public void CreatePersonDetailsRecord_CreateRecords_ReturnTrue
            (
            string firstName,string surName, string maritalStatus,string spouseName,string dateOfBirth, string ParentsAllowRegistration,
            string SpouseDetailsfilePath,string PersonDetailsfilePath,
            bool expectedResult_1
            ) {

            //var fileCreation = new Mock<IFileCreation>();

            PersonDetails personDetails = new PersonDetails()
            {
                FirstName = firstName,
                SurName = surName,
                IsMarried = bool.Parse(maritalStatus),
                SpouseName = spouseName,
                DateOfBirth = DateTime.Parse(dateOfBirth),
                ParentsAllowRegistration = ParentsAllowRegistration,

                SpousefilePath = SpouseDetailsfilePath,
                PersonDetailsfilePath = PersonDetailsfilePath
            };

            var result = personDetails.CreatePersonDetailsRecord(personDetails);

            Assert.That(result,Is.EqualTo(expectedResult_1));

        }



    }

}
